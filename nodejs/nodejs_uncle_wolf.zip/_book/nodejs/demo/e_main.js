var hello = require('./exports');

console.log(hello.name())