var hello = require('./helloworld2');

hello()