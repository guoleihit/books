module.exports = function (person) {
  console.log('hello world ' + person);
}