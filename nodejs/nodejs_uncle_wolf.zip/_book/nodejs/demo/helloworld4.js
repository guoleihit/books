function say(person) {
  console.log('hello world ' + person);
}

module.exports = say;