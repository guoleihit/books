var Person = require('./exports2');
var p = new Person('Ting', 20);
p.about(); // Ting is 20 years old