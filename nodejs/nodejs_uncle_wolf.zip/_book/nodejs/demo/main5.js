var h5 = require('./helloworld5')

h5.eat('兰州拉面');

h5.say('海角');