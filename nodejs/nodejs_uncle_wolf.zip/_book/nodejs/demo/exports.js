module.exports = 'Exports IT!';
exports.name = function () {
  console.log('hello world');
}