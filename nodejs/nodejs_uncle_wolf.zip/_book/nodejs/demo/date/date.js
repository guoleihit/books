var moment = require('moment');
var date = moment().format('YYYY-MM-DD');

exports.created_at = date;