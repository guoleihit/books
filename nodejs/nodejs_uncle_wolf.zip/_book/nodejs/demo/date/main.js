var date = require('./date');

console.log(date.created_at);