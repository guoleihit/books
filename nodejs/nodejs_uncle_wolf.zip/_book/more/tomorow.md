# 如何展望未来的大前端

- [为什么前端越来越难？越来越有意思？](https://cnodejs.org/topic/55101c79d792542a2978987d)
- [如何展望未来的前端](https://cnodejs.org/topic/55560e717cabb7b45ee6bc62)
