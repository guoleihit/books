# gitbook

## 入门

https://github.com/GitbookIO/gitbook/blob/master/docs/setup.md

## gulp发布到gh-pages

